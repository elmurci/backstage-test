from sys import exit
from bitcoin.core.script import *

from lib.utils import *
from lib.config import (my_private_key, my_public_key, my_address,
                    faucet_address, network_type)
from Q1 import send_from_P2PKH_transaction


######################################################################
# TODO: Complete the scriptPubKey implementation for Exercise 2
# x + y = 1975
# x - y = 1311
# y = 332
# x = 1643
Q2a_txout_scriptPubKey = [
        OP_2DUP,
        OP_ADD,
        1975,
        OP_EQUALVERIFY,
        OP_SUB,
        1311,
        OP_EQUAL,
    ]
######################################################################

if __name__ == '__main__':
    ######################################################################
    # TODO: set these parameters correctly
    amount_to_send = 0.00001 # amount of BTC in the output you're sending minus fee
    txid_to_spend = (
        'f1929c618fff0d8f50be5fe92ea88e6601ef557927086ae7c0e21fcb7ea05567')
    utxo_index = 0 # index of the output you are spending, indices start at 0
    ######################################################################

    response = send_from_P2PKH_transaction(
        amount_to_send, txid_to_spend, utxo_index,
        Q2a_txout_scriptPubKey, my_private_key, network_type)
    print(response.status_code, response.reason)
    print(response.text)
