from bitcoin import SelectParams
from bitcoin.base58 import decode
from bitcoin.core import x
from bitcoin.wallet import CBitcoinAddress, CBitcoinSecret, P2PKHBitcoinAddress


SelectParams('testnet')

faucet_address = CBitcoinAddress('mv4rnyY3Su5gjcDNzbMLKBQkBicCtHUtFB')

# For questions 1-3, we are using 'btc-test3' network. For question 4, you will
# set this to be either 'btc-test3' or 'bcy-test'
network_type = 'btc-test3'


######################################################################
# This section is for Questions 1-3
# TODO: Fill this in with your private key.
#
# Create a private key and address pair in Base58 with keygen.py
# Send coins at https://testnet-faucet.mempool.co/
# mmb7jBxn2k5Wn7gJLVjXwTsDCVAyK5zkkz
my_private_key = CBitcoinSecret(
    'cTrjgSGTzbc9tYBGHvjuF45kHKyAVJro1Fzje2wGpKKFn37gGcCF')

my_public_key = my_private_key.pub
my_address = P2PKHBitcoinAddress.from_pubkey(my_public_key)
######################################################################


######################################################################
# NOTE: This section is for Question 4
# DONE: Fill this in with address secret key for BTC testnet3
#
# Create address in Base58 with keygen.py
# Send coins at https://testnet-faucet.mempool.co/

# Only to be imported by alice.py
# Alice should have coins!!
# mnYyptc7EmpnrojUL18dL6V5dh6pWCpEex
alice_secret_key_BTC = CBitcoinSecret(
    'cRMSD7eyW72AbTk55bZirdLr5kkQk2JzdUzseB5pHt3Y8iNWVb4W')

# Only to be imported by bob.py
# mhSUaxXnqrAgTDsVVzx1GBkqgWtBK4SCv9
bob_secret_key_BTC = CBitcoinSecret(
    'cR6b9PkB1mWCsCBnCcLVYwDpGqihreord6JadbGvkLEw3w4wFRRk')

# Can be imported by alice.py or bob.py
alice_public_key_BTC = alice_secret_key_BTC.pub
alice_address_BTC = P2PKHBitcoinAddress.from_pubkey(alice_public_key_BTC)

bob_public_key_BTC = bob_secret_key_BTC.pub
bob_address_BTC = P2PKHBitcoinAddress.from_pubkey(bob_public_key_BTC)
######################################################################


######################################################################
# NOTE: This section is for Question 4
# DONE: Fill this in with address secret key for BCY testnet
#
# Create address in hex with
# curl -X POST https://api.blockcypher.com/v1/bcy/test/addrs?token=YOURTOKEN
# This request will return a private key, public key and address. Make sure to save these.
#
# Send coins with
# curl -d '{"address": "BCY_ADDRESS", "amount": 1000000}' https://api.blockcypher.com/v1/bcy/test/faucet?token=YOURTOKEN
# This request will return a transaction reference. Make sure to save this.

# Alice

# {
#   "private": "8ecc250b3bf9f7efdd5774cd00b0fa256511255606984d7fb49b064284ee5ecd",
#   "public": "032126eb9ada0a67afce64e9abfc21954f656febf91e824df646cf0355799bacf1",
#   "address": "BvpbbtuzCTF4KZ5oCLvTNRLjK1AzCd3i7E",
#   "wif": "Bt7cMSB1JxZuds65NGwZnvgqBMuKMu2nXyfQK4Kzqgx9MLoEpptx"
# }

# Bob

# {
#   "private": "020295d187c136cecea07d2c161411e1346eaebf4dbc496fe24a576779292433",
#   "public": "02113f5b852c52cc27fd32cb31b8e7d72490732b51e4e65caa595ba54f2b9fe048",
#   "address": "CC6GvybqtTXgtU8CdcbSJYer6PtW7uhBFx",
#   "wif": "BoPwNAsK3AC6zY1TVn3kxQvrCj3CDnut26HVQw8dMmjJ6WwJGCmS"
# }

# Only to be imported by alice.py
alice_secret_key_BCY = CBitcoinSecret.from_secret_bytes(
    x('8ecc250b3bf9f7efdd5774cd00b0fa256511255606984d7fb49b064284ee5ecd'))

# Only to be imported by bob.py
# Bob should have coins!!
bob_secret_key_BCY = CBitcoinSecret.from_secret_bytes(
    x('020295d187c136cecea07d2c161411e1346eaebf4dbc496fe24a576779292433'))

# Can be imported by alice.py or bob.py
alice_public_key_BCY = alice_secret_key_BCY.pub
alice_address_BCY = P2PKHBitcoinAddress.from_pubkey(alice_public_key_BCY)

bob_public_key_BCY = bob_secret_key_BCY.pub
bob_address_BCY = P2PKHBitcoinAddress.from_pubkey(bob_public_key_BCY)
######################################################################
